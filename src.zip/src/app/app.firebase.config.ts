export const FIREBASE_CONFIG = {
    apiKey: "AIzaSyBLeTpdh9GpeHsKrm9b-FdfySbtgfw15mk",
    authDomain: "fir-auth-b451a.firebaseapp.com",
    databaseURL: "https://fir-auth-b451a.firebaseio.com",
    projectId: "fir-auth-b451a",
    storageBucket: "fir-auth-b451a.appspot.com",
    messagingSenderId: "547347617660"
  };