import { Injectable } from '@angular/core';

import { Item } from '../../models/item';
import { Api } from '../api/api';
import { User } from '../user/user'
import { AngularFireDatabase } from "angularfire2/database";


const FIREBASE_USERPROFILE = 'Posts';
//const FIREBASE_USERPROFILE = 'StreamTag';


@Injectable()
export class Items {

  constructor(public api: Api, private db: AngularFireDatabase, private userObj: User) { }

  public query(onSuccess: (data) => void, onError: (data) => void = null): any {
    this.db.object(FIREBASE_USERPROFILE).valueChanges().subscribe((res: any) => {

      if (res == null) {
        onSuccess(null);
        return;
      }
      let currentItems = [];

      Object.keys(res).forEach(function (key) {
        console.log(key, res[key]);
        currentItems.push(res[key]);
      });

      onSuccess(currentItems)
    }, error => {
      onError(error);
    });

  }

  add(item: any, onSuccess: (data) => void, onError: (data) => void = null): any {
    var users = this.db.list(FIREBASE_USERPROFILE);
    const newBillRef = users.push({});
    newBillRef.set({
      description: "This is the post",
      id: this.userObj._user.uid
    }).then(newResp => {
      return newResp;
    }, error => {
      console.log(error);
    });
  }

  delete(item: any, onSuccess: (data) => void, onError: (data) => void = null): any {

    const itemsRef = this.db.list(FIREBASE_USERPROFILE);
    // to get a key, check the Example app below
    itemsRef.remove(item).then(newResp=>{

    },error => {
      
    });

  }

}

